<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Finanomics</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- favicon -->
<link rel="shortcut icon" href="assets/images/logo/favicon.png">
<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- Link to Uikit CSS -->
<link rel="stylesheet" href="uikit/css/uikit.css" />
<link rel="stylesheet" href="assets/stylesheets/custom.css" />
<!-- Animation, Icon Fonts, Bootsrap styles -->
<link rel='stylesheet' href='assets/stylesheets/vendor/aos.min.css' type='text/css' media='all' />	
<!-- Vendor Styles Section END-->
<!-- Link to custom CSS -->
<link rel="stylesheet" href="uikit/css/components/dotnav.min.css" />
<link rel="stylesheet" href="uikit/css/components/slideshow.min.css" />
<link rel="stylesheet" href="uikit/css/components/slidenav.min.css" />
<link rel="stylesheet" href="uikit/css/components/sticky.min.css" />
<link rel="stylesheet" href="assets/css/custom.css">