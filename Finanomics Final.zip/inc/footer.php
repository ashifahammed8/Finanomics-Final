<!-- Scripts section -->
	<script type='text/javascript' src='assets/js/vendor/jquery.js'></script>
	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<script type='text/javascript' src='assets/js/vendor/aos.min.js'></script>
	<script type='text/javascript' src='assets/js/vendor/jquery.waypoints.min.js'></script>
	<script type='text/javascript' src='assets/js/vendor/bootstrap.min.js'></script>
	<script type='text/javascript' src='assets/js/vendor/jarallax.min.js'></script>
	<script type='text/javascript' src='assets/js/vendor/velocity.min.js'></script>
	<script type='text/javascript' src='assets/js/vendor/waves.min.js'></script>
	<script type='text/javascript' src='assets/js/vendor/scrollspy.js'></script>
	<script type='text/javascript' src='assets/js/vendor/slick.min.js'></script>
	<script type='text/javascript' src='assets/js/vendor/isotope.pkgd.min.js'></script>
	<script type='text/javascript' src='assets/js/vendor/counterup.min.js'></script>
	<script type='text/javascript' src='assets/js/vendor/jquery.magnific-popup.min.js'></script>
	
	
	<!-- Vendor Script Section -->
	<script type="text/javascript" src="assets/js/vendor/revo/jquery.themepunch.tools.min.js"></script>
	<script type="text/javascript" src="assets/js/vendor/revo/jquery.themepunch.revolution.min.js"></script>
	<!-- Vendor Script Section END-->
	<script type='text/javascript' src='assets/js/startapp-theme.js'></script>
	<!-- Scripts section END -->
	<!-- Link to Uikit JS -->
	<script type="text/javascript" src="uikit/js/uikit.min.js"></script>
	<!-- Link to slideshow JS -->
	<script type="text/javascript" src="uikit/js/components/slideshow.min.js"></script>  
	<script type="text/javascript" src="uikit/js/components/slideshow-fx.min.js"></script>
	<script type="text/javascript" src="uikit/js/components/sticky.js"></script> 
	<script src="https://unpkg.com/scrollreveal/dist/scrollreveal.min.js"></script> 