<!-- Footer Goes here -->
<footer class="tm-footer uk-block uk-block-secondary uk-contrast uk-hidden-small">
	<div class="uk-container uk-container-center">
		<div class="uk-grid uk-hidden-small">
		    <div class="uk-width-1-1 uk-text-center">
		     &copy; copyright Finanomics.All Reserved 2018.
		 	</div>
		</div>
	</div>
</footer>
<!-- End of the footer -->

<!-- Mobile footer -->
<footer class="tm-footer uk-block uk-block-secondary uk-contrast uk-visible-small" data-uk-sticky>
	<div class="uk-container uk-container-center">
		<div class="uk-grid uk-visible-small">
		    <div class="uk-width-1-1 uk-text-center">
		     &copy; copyright All Reserved 2016.
		 	</div>
		</div>
	</div>
</footer>
<!-- End mobile footer -->